export { default } from './StudentDetailsPage';
