export { default } from './BatchComparisonChart';
